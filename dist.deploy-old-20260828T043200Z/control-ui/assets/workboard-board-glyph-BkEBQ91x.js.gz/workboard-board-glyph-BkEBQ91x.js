import{n as e}from"./rolldown-runtime-DkW27tQK.js";import{$r as t,Qr as n,ei as r}from"./control-ui-core-CRuVhLK8.js";import{E as i,J as a,O as o,W as s}from"./lit-runtime-Do8XtDrr.js";function c(e,n=``){return a`
    <span
      class="workboard-board-glyph ${n}"
      style=${o({"--workboard-board-color":t(e)})}
      aria-hidden="true"
      >${r(e)}</span
    >
  `}function l(){return(l=e((()=>{s(),i(),n()})))()}export{c as n,l as t};
//# sourceMappingURL=workboard-board-glyph-BkEBQ91x.js.map