import{n as e}from"./rolldown-runtime-DkW27tQK.js";import{dr as t}from"./control-ui-foundation-DcQugFIP.js";import{Bl as n,Er as r,Hl as i,Tr as a,br as o,vr as s,yr as c}from"./control-ui-core-BIRhUd0w.js";import{G as l,J as u,W as d}from"./lit-runtime-CFtfqA5r.js";import{$t as f,Nt as p,Rt as m,_n as h,d as g,f as _,gn as v,pn as y}from"./control-ui-core-BVHxUJX1.js";import{Ft as b,Pt as x,Wt as S,zt as C}from"./control-ui-core-BRyX5NDK.js";import{Rt as w,zt as T}from"./control-ui-boot-Bl3LK1Li.js";import{n as E,t as D}from"./settings-workspace-BYKXh08R.js";import{n as O,t as k}from"./brand-icons-B_VdV-QH.js";var A;function j(){return(j=e((()=>{d(),A={watch:u`
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="6" />
      <polyline points="12 10 12 12 13 13" />
      <path d="m16.13 7.66-.81-4.05a2 2 0 0 0-2-1.61h-2.68a2 2 0 0 0-2 1.61l-.78 4.05" />
      <path d="m7.88 16.36.8 4a2 2 0 0 0 2 1.61h2.72a2 2 0 0 0 2-1.61l.81-4.05" />
    </svg>
  `,apple:u`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        d="M17.05 12.54c-.03-2.62 2.14-3.88 2.24-3.94-1.22-1.79-3.12-2.03-3.8-2.06-1.61-.16-3.15.95-3.97.95-.82 0-2.08-.93-3.42-.9-1.76.03-3.38 1.02-4.29 2.6-1.83 3.17-.47 7.87 1.31 10.44.87 1.26 1.91 2.67 3.27 2.62 1.31-.05 1.81-.85 3.4-.85 1.58 0 2.03.85 3.42.82 1.41-.02 2.31-1.28 3.17-2.55.99-1.46 1.4-2.87 1.42-2.94-.03-.02-2.73-1.05-2.75-4.19Zm-2.6-7.68c.72-.88 1.21-2.09 1.08-3.3-1.04.04-2.3.69-3.05 1.56-.67.78-1.26 2.02-1.1 3.2 1.16.09 2.34-.59 3.07-1.46Z"
      />
    </svg>
  `,android:u`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        d="M17.52 15.05a.98.98 0 1 1 .01-1.96.98.98 0 0 1-.01 1.96m-11.04 0a.98.98 0 1 1 .01-1.96.98.98 0 0 1-.01 1.96m11.39-5.89 1.96-3.39a.4.4 0 0 0-.15-.55.4.4 0 0 0-.55.15l-1.98 3.43A12.03 12.03 0 0 0 12 7.75c-1.85 0-3.6.42-5.15 1.05L4.87 5.37a.4.4 0 0 0-.55-.15.4.4 0 0 0-.15.55l1.96 3.39C2.75 11 .48 14.42.14 18.4h23.72c-.34-3.98-2.61-7.4-5.99-9.24"
      />
    </svg>
  `,windows:u`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        d="M3 5.55 10.29 4.5v7.02H3V5.55Zm0 12.9 7.29 1.05v-6.93H3v5.88Zm8.09 1.16L21 21v-8.43h-9.91v7.04Zm0-15.22v7.13H21V3l-9.91 1.39Z"
      />
    </svg>
  `,linux:u`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        fill-rule="evenodd"
        d="M12 2c-2.76 0-5 2.24-5 5v3.1c0 1.35-.62 2.5-1.32 3.6C4.6 15.4 4 16.9 4 18.3 4 20.9 7.58 22 12 22s8-1.1 8-3.7c0-1.4-.6-2.9-1.68-4.6-.7-1.1-1.32-2.25-1.32-3.6V7c0-2.76-2.24-5-5-5Zm-2 4.5a1 1 0 1 1 0 2 1 1 0 0 1 0-2Zm4 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2Zm-2 2.7 1.8 1.3c.3.24.3.7-.02.92L12 12.6l-1.78-1.18a.58.58 0 0 1-.02-.93L12 9.2Z"
      />
    </svg>
  `,chrome:u`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        d="M12 2a10 10 0 0 1 8.66 5H12a5 5 0 0 0-4.79 3.57L4.4 5.72A9.98 9.98 0 0 1 12 2Zm9.54 7A10 10 0 0 1 12 22l-.34-.01 4.36-7.55A4.98 4.98 0 0 0 17 12c0-1.13-.37-2.16-1-3h5.54ZM3.35 7.57l4.36 7.56a5 5 0 0 0 6.16 2.24l-2.81 4.87A10 10 0 0 1 3.35 7.57ZM12 8.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7Z"
      />
    </svg>
  `}})))()}function M(e,t,n){let r=t===0?`apps-card__cta apps-card__cta--primary`:`apps-card__cta`;return e.kind===`internal`?u`
      <button type="button" class=${r} @click=${()=>n.onNavigate(e.routeId)}>
        ${e.label()}
      </button>
    `:u`
    <a
      class=${r}
      href=${e.href}
      target=${s}
      rel=${c()}
    >
      ${e.label()}
    </a>
  `}function N(e,t){let[n,r]=e.gradient;return u`
    <article class="apps-card">
      <div class="apps-card__art" style=${`--apps-art-a:${n};--apps-art-b:${r}`}>
        <img
          class="apps-card__art-img apps-card__art-img--light"
          src=${v(`app-art/${e.id}.webp`)}
          alt=""
          loading="lazy"
          decoding="async"
        />
        <img
          class="apps-card__art-img apps-card__art-img--dark"
          src=${v(`app-art/${e.id}-dark.webp`)}
          alt=""
          loading="lazy"
          decoding="async"
        />
      </div>
      <div class="apps-card__body">
        <div class="apps-card__title-row">
          <span class="apps-card__icon" aria-hidden="true">${e.icon}</span>
          <h3 class="apps-card__title">${e.title()}</h3>
          ${e.badge?u`<span class="apps-card__badge">${e.badge()}</span>`:l}
        </div>
        <p class="apps-card__desc">${e.desc()}</p>
        <div class="apps-card__ctas">
          ${e.ctas.map((e,n)=>M(e,n,t))}
        </div>
      </div>
    </article>
  `}function P(e,t){let n=e.id===`mobile`&&t.onPairDevice?u`
          <p class="apps-pair-hint">
            ${S(`appsPage.havePhone`)}
            <button type="button" @click=${t.onPairDevice}>
              ${S(`appsPage.pairDevice`)}
            </button>
          </p>
        `:l;return u`
    <section class="apps-section" aria-label=${e.label()}>
      <h2 class="apps-section__heading">${e.label()}</h2>
      <div class="apps-grid">${e.cards.map(e=>N(e,t))}</div>
      ${n}
    </section>
  `}function F(){return u`
    <section class="apps-section" aria-label=${S(`appsPage.sectionCommunity`)}>
      <h2 class="apps-section__heading">${S(`appsPage.sectionCommunity`)}</h2>
      <nav class="apps-community" aria-label=${S(`appsPage.sectionCommunity`)}>
        ${z.map(e=>u`
            <a
              class="apps-pill"
              href=${e.href}
              target=${s}
              rel=${c()}
            >
              <span class="apps-pill__icon" aria-hidden="true">${e.icon}</span>
              <span>${e.label()}</span>
            </a>
          `)}
      </nav>
    </section>
  `}function I(e){return u`
    <div class="apps-page">
      <section class="apps-hero">
        <h1 class="apps-hero__title">${S(`appsPage.heroTitle`)}</h1>
        <p class="apps-hero__tagline">${S(`appsPage.heroTagline`)}</p>
      </section>
      ${R.map(t=>P(t,e))} ${F()}
    </div>
  `}var L,R,z;function B(){return(B=e((()=>{d(),h(),b(),C(),o(),O(),j(),L=e=>({kind:`external`,href:`https://docs.openclaw.ai${e}`,label:()=>S(`appsPage.ctaDocs`)}),R=[{id:`mobile`,label:()=>S(`appsPage.sectionMobile`),cards:[{id:`ios`,gradient:[`#38bdf8`,`#1d4ed8`],icon:A.apple,title:()=>S(`appsPage.cards.ios.title`),desc:()=>S(`appsPage.cards.ios.desc`),ctas:[{kind:`external`,href:`https://apps.apple.com/app/openclaw-ai-that-does-things/id6780396132`,label:()=>S(`appsPage.ctaAppStore`)},L(`/platforms/ios`)]},{id:`android`,gradient:[`#34d399`,`#047857`],icon:A.android,title:()=>S(`appsPage.cards.android.title`),desc:()=>S(`appsPage.cards.android.desc`),ctas:[{kind:`external`,href:`https://play.google.com/store/apps/details?id=ai.openclaw.app`,label:()=>S(`appsPage.ctaPlayStore`)},L(`/platforms/android`)]}]},{id:`watch`,label:()=>S(`appsPage.sectionWatch`),cards:[{id:`apple-watch`,gradient:[`#f472b6`,`#be185d`],icon:A.watch,title:()=>S(`appsPage.cards.appleWatch.title`),desc:()=>S(`appsPage.cards.appleWatch.desc`),badge:()=>S(`appsPage.badgeBundledIos`),ctas:[L(`/platforms/ios`)]},{id:`wear-os`,gradient:[`#22d3ee`,`#0e7490`],icon:A.watch,title:()=>S(`appsPage.cards.wearOs.title`),desc:()=>S(`appsPage.cards.wearOs.desc`),badge:()=>S(`appsPage.badgeBundledAndroid`),ctas:[L(`/platforms/android`)]}]},{id:`desktop`,label:()=>S(`appsPage.sectionDesktop`),cards:[{id:`macos`,gradient:[`#a855f7`,`#6b21a8`],icon:A.apple,title:()=>S(`appsPage.cards.macos.title`),desc:()=>S(`appsPage.cards.macos.desc`),ctas:[{kind:`external`,href:`https://github.com/openclaw/openclaw/releases`,label:()=>S(`appsPage.ctaDownload`)},L(`/platforms/macos`)]},{id:`windows`,gradient:[`#818cf8`,`#4338ca`],icon:A.windows,title:()=>S(`appsPage.cards.windows.title`),desc:()=>S(`appsPage.cards.windows.desc`),ctas:[{kind:`external`,href:`https://github.com/openclaw/openclaw-windows-node/releases/latest`,label:()=>S(`appsPage.ctaDownload`)},L(`/platforms/windows`)]},{id:`linux`,gradient:[`#fbbf24`,`#b45309`],icon:A.linux,title:()=>S(`appsPage.cards.linux.title`),desc:()=>S(`appsPage.cards.linux.desc`),ctas:[{kind:`external`,href:`https://github.com/openclaw/openclaw/releases`,label:()=>S(`appsPage.ctaDownload`)},L(`/platforms/linux`)]}]},{id:`browser`,label:()=>S(`appsPage.sectionBrowser`),cards:[{id:`chrome-extension`,gradient:[`#f59e0b`,`#ea580c`],icon:A.chrome,title:()=>S(`appsPage.cards.chrome.title`),desc:()=>S(`appsPage.cards.chrome.desc`),ctas:[{kind:`external`,href:`https://chromewebstore.google.com/detail/openclaw/kcdjddhmeafeomebliikmbpblkmkfoig`,label:()=>S(`appsPage.ctaChromeWebStore`)},{kind:`external`,href:`https://docs.openclaw.ai/tools/chrome-extension`,label:()=>S(`appsPage.ctaSetupGuide`)}]},{id:`plugins`,gradient:[`#fb7185`,`#9f1239`],icon:x.puzzle,title:()=>S(`appsPage.cards.plugins.title`),desc:()=>S(`appsPage.cards.plugins.desc`),ctas:[{kind:`internal`,routeId:`plugins`,label:()=>S(`appsPage.ctaOpenPlugins`)},{kind:`external`,href:`https://clawhub.ai`,label:()=>S(`appsPage.ctaBrowseClawHub`)}]}]}],z=[{href:`https://discord.gg/clawd`,icon:k.discord,label:()=>S(`appsPage.linkDiscord`)},{href:`https://docs.openclaw.ai`,icon:x.book,label:()=>S(`appsPage.linkDocs`)}]})))()}var V;function H(){return(H=e((()=>{T(),d(),f(),_(),m(),D(),i(),r(),B(),V=class extends n{constructor(...e){super(...e),this.subscriptions=new a(this).watch(()=>this.context?.gateway,(e,t)=>e.subscribe(t))}disconnectedCallback(){this.subscriptions.clear(),super.disconnectedCallback()}render(){let e=this.context.gateway.snapshot,t=I({onNavigate:e=>this.context.navigate(e),onPairDevice:e.phase===`connected`&&p(e.hello?.auth??null)?()=>void this.context.overlays.openDevicePairSetup():void 0});return u`
      <section class="content-header">
        <div>
          <div class="page-title">${y(`apps`)}</div>
        </div>
      </section>
      ${E(t)}
    `}},t([w({context:g,subscribe:!0})],V.prototype,`context`,void 0),customElements.get(`openclaw-apps-page`)||customElements.define(`openclaw-apps-page`,V)})))()}H();
//# sourceMappingURL=apps-page-DTzqyNU0.js.map